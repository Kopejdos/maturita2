package com.example.klakulacka;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;


public class CalcCON {


    @FXML
    private TextField textField;

    @FXML
    private Text savedNumbers;

    private String firstNumber = "";

    private String currentNumber = "";

    private String lastDigit = "";

    private double answerValue = 0.0;

    private String calculationType;

    private int point = 0;

    //------------------------------------------------------------------------------------------------------------------
    //CHARAKTERS
    @FXML
    void addAction(ActionEvent event) {
        if (!currentNumber.isEmpty()){
            calculationSetup("+");
        }
    }

    @FXML
    void minusAction(ActionEvent event) {
        if (!currentNumber.isEmpty()) {
            calculationSetup("-");
        }
    }

    @FXML
    void divideAction(ActionEvent event) {
        if (!currentNumber.isEmpty()) {
            calculationSetup("/");
        }
    }

    @FXML
    void multiplicationAction(ActionEvent event) {
        if (!currentNumber.isEmpty()) {
            calculationSetup("*");
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    //CALCULATION PROCES WITHOUT PERCENT
    public void calculationSetup(String calculationType){
        this.calculationType = calculationType;
        firstNumber = currentNumber;
        currentNumber = "";
        savedNumbers.setText(firstNumber + " " + calculationType);
    }

    @FXML
    void calculate(ActionEvent event) {//MEZI ZNAK
        if(!firstNumber.isEmpty() && !currentNumber.isEmpty()) {
            double firstNumberDouble = Double.parseDouble(firstNumber);
            double secondNumberDouble = Double.parseDouble(currentNumber);

            switch (calculationType) {
                case "+" -> {//PLUS
                    double calculatedNumber = firstNumberDouble + secondNumberDouble;
                    savedNumbers.setText(firstNumber + " + " + currentNumber + " = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    answerValue = calculatedNumber;
                }
                case "-" -> {//MINUS
                    double calculatedNumber = firstNumberDouble - secondNumberDouble;
                    savedNumbers.setText(firstNumber + " - " + currentNumber + " = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    answerValue = calculatedNumber;
                }
                case "/" -> {//DĚLENO
                    if (secondNumberDouble != 0) {
                        double calculatedNumber = firstNumberDouble / secondNumberDouble;
                        savedNumbers.setText(firstNumber + " / " + currentNumber + " = " + calculatedNumber);
                        textField.setText(String.valueOf(calculatedNumber));
                        answerValue = calculatedNumber;
                    } else {
                        savedNumbers.setText("Error: Division by zero");
                        textField.setText("Error");
                    }
                }
                case "*" -> {//KRÁT
                    double calculatedNumber = firstNumberDouble * secondNumberDouble;
                    savedNumbers.setText(firstNumber + " * " + currentNumber + " = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    answerValue = calculatedNumber;
                }
            }
            this.answer(event);
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    //CALCULATION PROCES WITH PERCENT
    @FXML
    void buttonPclicked(ActionEvent event) {
        if (!currentNumber.isEmpty()) {
            double value = Double.parseDouble(currentNumber);
            double percentage = value / 100.0;

            switch (calculationType) {
                case "+" -> {
                    double calculatedNumber = Double.parseDouble(firstNumber) + (Double.parseDouble(firstNumber) * percentage);
                    savedNumbers.setText(firstNumber + " + " + currentNumber + "% = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    currentNumber = String.valueOf(calculatedNumber);
                }
                case "-" -> {
                    double calculatedNumber = Double.parseDouble(firstNumber) - (Double.parseDouble(firstNumber) * percentage);
                    savedNumbers.setText(firstNumber + " - " + currentNumber + "% = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    currentNumber = String.valueOf(calculatedNumber);
                }
                case "*" -> {
                    double calculatedNumber = value * percentage;
                    savedNumbers.setText(currentNumber + "% = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    currentNumber = String.valueOf(calculatedNumber);
                }
                case "/" -> {
                    double calculatedNumber = value / percentage;
                    savedNumbers.setText(currentNumber + "% = " + calculatedNumber);
                    textField.setText(String.valueOf(calculatedNumber));
                    currentNumber = String.valueOf(calculatedNumber);
                }
            }
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    //SPECIAL BUTTONS
    @FXML //CLEAR ALL
    void clearTextField(ActionEvent event) {
        currentNumber = "";
        textField.setText("");
        savedNumbers.setText("");
        point = 0;
    }

    @FXML //CLEAR LAST DIGIT
    void backSpace(ActionEvent event) {
        if (currentNumber.length() > 0) {
            lastDigit = currentNumber.substring(currentNumber.length() - 1);
            currentNumber = currentNumber.substring(0, currentNumber.length() - 1);
            updateTextField();
        }
        if (currentNumber.length() > 0 || lastDigit == ".") {
            lastDigit = currentNumber.substring(currentNumber.length() - 1);
            currentNumber = currentNumber.substring(0, currentNumber.length() - 1);
            updateTextField();
            point =0;
        }
    }

    @FXML // ANSWER FROM PREVIOUS CALCULATION
    void answer(ActionEvent event) {
        if (answerValue != 0.0) {
            currentNumber = String.valueOf(answerValue);
            updateTextField();
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    //NUMBERS
    @FXML
    void button0Clicked(ActionEvent event) {
        addNumber("0");//0
    }

    @FXML
    void button1Clicked(ActionEvent event) {
        addNumber("1");//1
    }

    @FXML
    void button2Clicked(ActionEvent event) {
        addNumber("2");//2
    }

    @FXML
    void button3Clicked(ActionEvent event) {
        addNumber("3");//3
    }

    @FXML
    void button4Clicked(ActionEvent event) {
        addNumber("4");//4
    }

    @FXML
    void button5Clicked(ActionEvent event) {
        addNumber("5");//5
    }

    @FXML
    void button6Clicked(ActionEvent event) {
        addNumber("6");//6
    }

    @FXML
    void button7Clicked(ActionEvent event) {
        addNumber("7");//7
    }

    @FXML
    void button8Clicked(ActionEvent event) {
        addNumber("8");//8
    }

    @FXML
    void button9Clicked(ActionEvent event) {
        addNumber("9");//9
    }

    @FXML
    void buttonDclicked(ActionEvent event) {
        if(currentNumber.isEmpty()){
            addNumber("0.");
            point = 1;
        }else {
            addNumber(".");
            point = 1;
        }
    }

    //------------------------------------------------------------------------------------------------------------------

    public void updateTextField(){
        textField.setText(currentNumber);
    }

    public void addNumber(String number){
        if (point == 0 || number!="."){
            currentNumber += number;
            updateTextField();
        }else {
            textField.setText(currentNumber);
        }
    }

}