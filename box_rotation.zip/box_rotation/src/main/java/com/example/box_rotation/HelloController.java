package com.example.box_rotation;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Slider;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;


import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Rectangle kostka;

    @FXML
    private Slider rotator;

    private Rotate rotateTransform;

    private double centerX, centerY;

    @FXML
    private Text uhel;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Získání středu kostky
        centerX = kostka.getX() + kostka.getWidth() / 2;
        centerY = kostka.getY() + kostka.getHeight() / 2;

        // Vytvoření transformace Rotate s umístěním středu otáčení v prostředku kostky
        rotateTransform = new Rotate();
        rotateTransform.setPivotX(centerX);
        rotateTransform.setPivotY(centerY);

        // Přidání transformace na kostku
        kostka.getTransforms().add(rotateTransform);


        // Nastavení listeneru na změnu hodnoty slideru
        rotator.valueProperty().addListener((observable, oldValue, newValue) -> {
            rotateTransform.setAngle(newValue.doubleValue());
            uhel.setText(String.format("%.0f deg", newValue));
        });

        // Nastavení kroků slideru
        rotator.setMajorTickUnit(45); // Každých 45 stupňů
        rotator.setMinorTickCount(4); // Malé čárky mezi velkými
        rotator.setSnapToTicks(true); // Zamagnetuje na kroky slideru
        rotator.setShowTickMarks(true); // Zobrazí čárové značky


    }
}
