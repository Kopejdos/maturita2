module com.example.box_rotation {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.box_rotation to javafx.fxml;
    exports com.example.box_rotation;
}